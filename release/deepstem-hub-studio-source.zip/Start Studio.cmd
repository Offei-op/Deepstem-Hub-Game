@echo off
setlocal
cd /d "%~dp0"
echo Starting Deepstem Studio. Existing studio hosts will be restarted automatically.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" scripts\launch.py %*
) else (
  where py >nul 2>nul
  if not errorlevel 1 (
    py -3 scripts\launch.py %*
  ) else (
    python scripts\launch.py %*
  )
)
if errorlevel 1 (
  echo.
  echo Studio could not start. Read the message above for the next step.
  pause
)
