import {APP_URL,PREVIEW_URL} from './urls'
import {test,expect} from '@playwright/test'
import {mkdir,writeFile} from 'node:fs/promises'

test('readable creative workflow at 1366×768 and 1920×1080',async({browser,page})=>{
 test.setTimeout(120000)
 await mkdir('../artifacts/ux-overhaul',{recursive:true})
 await page.goto('/admin')
 await page.getByLabel('Organizer password',{exact:true}).fill('browser-test-password-2026')
 await page.getByRole('button',{name:'Open control room'}).click()
 await expect(page.getByRole('heading',{name:'Get your game jam ready'})).toBeVisible()
 const session=await (await page.request.get('/api/auth/session')).json()
 const headers={'Origin':APP_URL,'X-CSRF-Token':session.csrf}
 await page.request.post('/api/admin/timer',{headers,data:{action:'reset',minutes:120}})
 await page.request.patch('/api/admin/event',{headers,data:{frozen:false,paused:false,emergency_mode:false,primary:'mock',fallback:''}})
 await page.request.post('/api/admin/timer',{headers,data:{action:'start'}})
 await page.reload()
 const created=await page.request.post('/api/admin/teams',{headers,data:{name:'Curious Creators'}})
 expect(created.ok()).toBe(true)
 const code=(await created.json()).code
 const teamContext=await browser.newContext()
 const guestContext=await browser.newContext()
 const guest=await guestContext.newPage()
 await guest.goto(APP_URL+'/')
 await expect(guest.getByRole('heading',{name:'Hey, game maker.'})).toBeVisible()
 const team=await teamContext.newPage()
 await team.goto(APP_URL+'/')
 await team.getByLabel('Your team access code').fill(code)
 await team.getByRole('button',{name:'Enter the studio'}).click()
 await expect(team.getByRole('heading',{name:'Big ideas. Playable worlds.'})).toBeVisible()
 const measurements=[]
 for(const size of [{width:1366,height:768},{width:1920,height:1080}]){
  const name=`${size.width}x${size.height}`
  await guest.setViewportSize(size)
  await guest.screenshot({path:`../artifacts/ux-overhaul/login-team-${name}.png`,animations:'disabled'})
  await guest.locator('.login-modes button').nth(1).click()
  await guest.screenshot({path:`../artifacts/ux-overhaul/login-organizer-${name}.png`,animations:'disabled'})
  await guest.locator('.login-modes button').nth(0).click()
  await page.setViewportSize(size);await page.evaluate(()=>scrollTo(0,0))
  await page.screenshot({path:`../artifacts/ux-overhaul/organizer-${name}.png`})
  await page.getByRole('button',{name:'Connect AI',exact:true}).click()
  await expect(page.getByRole('dialog',{name:'Connect your AI assistant'})).toBeVisible()
  await expect(page.getByRole('button',{name:'Save AI connection'})).toBeEnabled()
  await page.screenshot({path:`../artifacts/ux-overhaul/connect-ai-${name}.png`,animations:'disabled'})
  await page.getByRole('button',{name:'Close dialog'}).click()
  await team.setViewportSize(size);await team.evaluate(()=>scrollTo(0,0))
  await team.screenshot({path:`../artifacts/ux-overhaul/studio-empty-${name}.png`})
  const sizes=await team.evaluate(()=>{
   const px=(s:string)=>parseFloat(getComputedStyle(document.querySelector(s)!).fontSize)
   return {width:innerWidth,height:innerHeight,zoom:devicePixelRatio,body:px('body'),description:px('.workspace-intro p'),composer:px('#game-prompt'),button:px('.generate-button'),heading:px('.panel-heading h2'),pageWidth:document.documentElement.scrollWidth,editor:document.querySelector('#game-prompt')!.getBoundingClientRect().toJSON(),generate:document.querySelector('.generate-button')!.getBoundingClientRect().toJSON()}
  })
  measurements.push(sizes)
  expect(sizes.body).toBeGreaterThanOrEqual(16);expect(sizes.description).toBeGreaterThanOrEqual(14)
  expect(sizes.composer).toBeGreaterThanOrEqual(16);expect(sizes.button).toBeGreaterThanOrEqual(15)
  expect(sizes.heading).toBeGreaterThanOrEqual(20);expect(sizes.pageWidth).toBeLessThanOrEqual(size.width)
  expect(sizes.editor.height).toBeGreaterThanOrEqual(160)
  expect(sizes.generate.bottom).toBeLessThanOrEqual(size.height)
  expect(await page.getByRole('button',{name:'Connect AI',exact:true}).evaluate(el=>el.getBoundingClientRect().height)).toBeGreaterThanOrEqual(44)
 }
 await team.getByRole('textbox',{name:'Describe your game or changes'}).fill('Create a colorful arcade game where I collect stars')
 await team.getByRole('button',{name:'Generate game',exact:true}).click()
 await expect(team.getByTitle('Cosmic Collector preview')).toBeVisible()
 for(const size of [{width:1366,height:768},{width:1920,height:1080}]){
  await team.setViewportSize(size);await team.evaluate(()=>scrollTo(0,0))
  await team.screenshot({path:`../artifacts/ux-overhaul/studio-playing-${size.width}x${size.height}.png`})
  await team.screenshot({path:`../artifacts/ux-overhaul/studio-full-${size.width}x${size.height}.png`,fullPage:true})
 }
 // Save configuration through the actual form without sending a paid generation.
 await page.getByRole('button',{name:'Connect AI',exact:true}).click()
 await page.getByLabel('API key',{exact:true}).fill('browser-test-key-never-a-real-credential')
 await page.getByLabel('Model ID',{exact:false}).fill('browser-test-model')
 await page.getByLabel('Input price',{exact:true}).fill('1')
 await page.getByLabel('Output price',{exact:true}).fill('2')
 await page.getByLabel('Use this provider for new games').uncheck()
 await page.getByRole('button',{name:'Save AI connection'}).click()
 await expect(page.getByText('AI connection saved and ready. No paid request was made.')).toBeVisible()
 await expect(page.getByPlaceholder('Enter a replacement key (optional)')).toHaveValue('')
 await writeFile('../artifacts/ux-overhaul/measurements.json',JSON.stringify(measurements,null,2))
 await teamContext.close()
 await guestContext.close()
})
